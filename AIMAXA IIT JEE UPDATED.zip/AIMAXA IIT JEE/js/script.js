document.addEventListener("DOMContentLoaded", function () {
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(navLink => {
        navLink.addEventListener('click', function () {
            // Toggle 'active' class for all nav-links
            navLinks.forEach(link => {
                link.classList.remove('active');
            });

            this.classList.toggle('active');
        });
    });
});
