//  1A , 2A , 3C , 4D , 5[A,B,C] , 6A , 7[C,D] , 8C, 9[A,D,E] , 10[A,C] , 11[B,D], 12A , 13[C,D] , 14A , 15B , 16C , 17D , 18B , 19[A,C,E] , 20A , 21[B,D] ,22[A,B,D,E] ,23[A,C,E], 24[B,E], 25[A,B,C,D]

function calculateResult() {
    let score = 0;

    // Define the correct answers for each question
    const correctAnswers = {
        question1: ['A'],
        question2: ['A'],
        question3: ['C'],
        question4: ['D'],
        question5: ['A','B','C'],
        question6: ['A'],
        question7: ['C','D'],
        question8: ['C'],
        question9: ['A','D','E'],
        question10: ['A','C'],
        question11: ['B','D'],
        question12: ['A'],
        question13: ['C','D'],
        question14: ['A'],
        question15: ['B'],
        question16: ['C'],
        question17: ['D'],
        question18: ['B'],
        question19: ['A','C','E'],
        question20: ['A'],
        question21: ['B','D'],
        question22: ['A','B','D','E'],
        question23: ['A','C','E'],
        question24: ['B','E'],
        question25: ['A','B','C','D'],
    };

    // Iterate through each question
    for (let i = 1; i <= 25; i++) {
        const questionName = `question${i}`;
        const checkboxes = document.getElementsByName(questionName);
        const userAnswers = Array.from(checkboxes).filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);

        // Check if the user's answers match the correct answers
        if (arraysEqual(userAnswers, correctAnswers[questionName])) {
            score++;
        }
    }

    window.location.href = `SAP_MM_results.html?score=${score}`;

    // You can redirect or perform other actions as needed

    return false; // Prevent the default form submission
}

// Function to check if two arrays are equal
function arraysEqual(arr1, arr2) {
    if (!Array.isArray(arr1) || !Array.isArray(arr2)) {
        return false; // Not arrays, consider them not equal
    }
    return arr1.length === arr2.length && arr1.every(value => arr2.includes(value));
}


